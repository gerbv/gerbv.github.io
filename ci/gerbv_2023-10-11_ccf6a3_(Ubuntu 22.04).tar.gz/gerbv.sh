#!/bin/bash

DIRECTORY=`dirname "$0"`
LD_LIBRARY_PATH="${LD_LIBRARY_PATH}:${DIRECTORY}" "${DIRECTORY}/gerbv" "$@"
